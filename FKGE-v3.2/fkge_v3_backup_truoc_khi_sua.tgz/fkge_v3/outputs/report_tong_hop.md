# Báo cáo kết quả thực nghiệm FKG-E


## KB1: FKG-E vs FISA trên FKG gốc

| Bộ dữ liệu | |R| | FISA Acc | FISA BalAcc | FISA AUC | FISA F1 | FISA bảng tra ms | FISA tuần tự ms | FKG-E Acc (mean) | std | FKG-E F1 | FKG-E ms/query | Speedup / bảng tra | Speedup / tuần tự |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Diabetes-Kaggle | 250 | 0.6250 | 0.6538 | 0.7241 | 0.6229 | 0.0190 | 0.0926 | 0.6312 | 0.0563 | 0.6198 | 0.0276 | 0.6878 | 3.3557 |
| Healthcare-Diabetes-Kaggle | 250 | 0.6250 | 0.6331 | 0.6979 | 0.6000 | 0.0189 | 0.0941 | 0.6562 | 0.0938 | 0.6142 | 0.0280 | 0.6743 | 3.3616 |
| BRSET (FKG-MM) | 250 | 0.7500 | 0.7552 | 0.8262 | 0.7460 | 0.0187 | 0.0932 | 0.7875 | 0.0000 | 0.7761 | 0.0275 | 0.6785 | 3.3865 |

![KB1](figures/kb1_comparison.png)


## KB2: FKG-E vs FISA trên FKGS đã lấy mẫu

| Cấu hình | |R| | FISA Acc | FKG-E Acc | Speedup |
|---|---|---|---|---|
| BRSET (FKG-MM đầy đủ) | 250 | 0.7500 | 0.7875 | 0.6866 |
| BRSET (FKGS đã nén) | 75 | 0.6750 | 0.7625 | 0.8488 |

**Kết luận:** CỘNG HƯỞNG (speedup tăng thêm khi kết hợp FKGS+FKG-E)


## KB3: Độ nhạy theo chiều nhúng d

| d | Accuracy (mean) | std | ms/query | TG huấn luyện (s) | FISA Acc (đối chiếu) |
|---|---|---|---|---|---|
| 8 | 0.5750 | 0.0250 | 0.0252 | 0.1604 | 0.6375 |
| 32 | 0.6000 | 0.0625 | 0.0272 | 0.1812 | 0.6375 |

![KB3](figures/kb3_dim_sensitivity.png)


## KB4: Độ nhạy theo (λ, β)

| λ_I | λ_P | ρ = λ_I/λ_P | Accuracy | std | Đồng thuận FISA (R2) | Dev căn cứ luật (R3) |
|---|---|---|---|---|---|---|
| 0.3000 | 0.3000 | 1.0000 | 0.5250 | 0.0000 | 0.6000 | 0.5390 |
| 0.3000 | 1.0000 | 0.3000 | 0.4625 | 0.0750 | 0.6375 | 0.5277 |
| 1.0000 | 0.3000 | 3.3333 | 0.6125 | 0.0375 | 0.6875 | 0.4708 |
| 1.0000 | 1.0000 | 1.0000 | 0.6000 | 0.0625 | 0.6500 | 0.5157 |

![KB4](figures/kb4_heatmap.png)


## KB5: Độ nhạy theo (w, K)

| w (cửa sổ) | K (mẫu âm) | Accuracy | std |
|---|---|---|---|
| toàn luật | 2 | 0.5938 | 0.0563 |
| toàn luật | 5 | 0.6000 | 0.0625 |

![KB5](figures/kb5_wK_sensitivity.png)


## KB6: Khả năng mở rộng quy mô

| Tỉ lệ mẫu | |R| | FISA ms/query | FKG-E ms/query | FISA Acc | FKG-E Acc |
|---|---|---|---|---|---|
| 0.4000 | 100 | 0.0189 | 0.0227 | 0.6125 | 0.6000 |
| 1.0000 | 250 | 0.0188 | 0.0277 | 0.6375 | 0.6000 |

![KB6](figures/kb6_scalability.png)

**Lưu ý đọc kết quả:** nếu đường FISA gần như phẳng còn FKG-E tăng theo |R|, đây là hệ quả đúng của việc FISA tiền tính ma trận trọng số một lần (Mệnh đề 3.2.11), KHÔNG phải dấu hiệu lỗi.


## Ablation Study

| Biến thể | Accuracy | BalAcc | AUC | F1 | Log-loss | Đồng thuận FISA (R2) | Dev căn cứ luật (R3) |
|---|---|---|---|---|---|---|---|
| Full FKG-E | 0.6000 | 0.5940 | 0.6410 | 0.5540 | 0.6181 | 0.6500 | 0.5157 |
| Bỏ L_pred (λ_P = 0) | 0.5563 | 0.6015 | 0.6414 | 0.5524 | 0.6548 | 0.6812 | 0.4723 |
| Bỏ L_inf (λ_I = 0) | 0.4313 | 0.5388 | 0.6111 | 0.4179 | 0.6252 | 0.5938 | 0.5807 |
| Bỏ L_rule (λ_R = 0) | 0.5563 | 0.5865 | 0.6204 | 0.5405 | 0.6226 | 0.6813 | 0.5625 |
| Bỏ bảo toàn cạnh (λ_E = 0) | 0.6313 | 0.6072 | 0.6328 | 0.5843 | 0.6173 | 0.7063 | 0.4658 |
| Bỏ bảo toàn nút (λ_N = 0) | 0.6312 | 0.5972 | 0.6303 | 0.5755 | 0.6179 | 0.6812 | 0.4847 |
| Bỏ cấu trúc (λ_E = λ_N = 0) | 0.5813 | 0.5702 | 0.6214 | 0.5302 | 0.6235 | 0.6438 | 0.5166 |
| Gộp trung bình đều (α = r/(r+1)) | 0.5375 | 0.5876 | 0.6763 | 0.5356 | 0.6083 | 0.7125 | 0.4750 |

![Ablation](figures/ablation_comparison.png)

**Lưu ý:** nếu Accuracy giống nhau giữa các biến thể nhưng Log-loss khác nhau, các thành phần vẫn có đóng góp thật về độ tin cậy dự đoán — không kết luận vội 'không có tác dụng'.


## So sánh Baseline (FISA / FKG-E / Node2Vec / TransE / DistMult)

| Phương pháp | Accuracy | F1 | TG huấn luyện (s) | ms/query |
|---|---|---|---|---|
| FISA (Chương 2) | 0.6375 | 0.6329 | 0.0012 | 0.0189 |
| Node2Vec + kNN | 0.5750 | 0.5451 | 0.8454 | 0.0143 |
| TransE + kNN | 0.6062 | 0.5099 | 0.1872 | 0.0138 |
| DistMult + kNN | 0.6625 | 0.6457 | 0.3909 | 0.0140 |
| FKG-E (đề xuất) | 0.6000 | 0.5540 | 0.1736 | 0.0280 |

![Baseline](figures/baseline_comparison.png)
